# TSE003
TSE assignment 003

This repositry contains both old sample code and up to date versions of the LiBot chatbot.

The 'LiBot v1.0 code' folder contains direct copies of 'LiBot.py' and 'Knowledge_Base.xlsx' in a runnable file structure (as long as all dependencies are installed). Please refer to this folder for all relevent source code and resources.

The executable for the LiBot program can be found on the official LiBot blog:
https://libot.blogs.lincoln.ac.uk/
